#include "stm32f3xx.h"   // Device header

//These variables handle the button press

enum output{potentiometer, encoder, average};
enum output currentOutput;
enum output nextOutput = potentiometer;

//Throttle position
int Ascending = 1; // Sets direction
int maxAmp = 511; // Sets the max amplitude of the triangle wave
int throttlePos = 1;
int resolution = 1;

//Encoder/decoder
int prevCharA , prevCharB, curCharA, curCharB; //store current and previous cycles for decoded channel A & B
int encoderOutput = 10;
int encoderCounter = 1;

int main(void)
{
	//Initialise LEDs
	RCC->AHBENR |= RCC_AHBENR_GPIOEEN;	// Enable clock on GPIO port E
	GPIOE->MODER |= 0x55550000;	//Set E.8-15 (onboard LEDs) to output mode
	GPIOE->OTYPER &= ~(0x0000FF00);//Set output type to push/pull
	GPIOE->PUPDR |= 0x55550000;	//Configure as Pull-up

	// Initialise DAC
	RCC->APB1ENR |= RCC_APB1ENR_DAC1EN; // Enable DAC Clock
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN; // Enable GPIOA Clock
	GPIOA->MODER |= 0x00000200; // Set PA.4 to analogue
	DAC1->CR |= DAC_CR_BOFF1;	// Disable DAC buffer
	DAC1->CR |= DAC_CR_EN1; // Enable DAC peripheral
	
	// Initialise the trianlge wave
	RCC->APB1ENR |= RCC_APB1ENR_TIM3EN; // Enable timer clock
	TIM3->PSC = 799; 
	TIM3->ARR = 19; //Sets a frequency of 1Hz 
	TIM3->DIER |= TIM_DIER_UIE; // Set DIER register to watch for update
	NVIC_EnableIRQ(TIM3_IRQn); // Enable timer 3 interrupt request in NVIC
	TIM3->CR1 |= TIM_CR1_CEN; // Start timer 3
	
	//Enable external interrupt with PA.0 button
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN; // Enable clock on system configuration controller
	EXTI->IMR |= EXTI_IMR_MR0; // Unmask EXTI0
	EXTI->IMR |= EXTI_IMR_MR2;
	EXTI->IMR |= EXTI_IMR_MR3;
	
	//External triggered Interrupt service routine on NVIC
	NVIC_EnableIRQ(EXTI0_IRQn);
	NVIC_EnableIRQ(EXTI2_TSC_IRQn);
	NVIC_EnableIRQ(EXTI3_IRQn);
	
	//PA.0 multiplexer interrupts
	SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI0_PA;
	SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI3_PC;
	SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI2_PC;
	
	// User button rising edge interrupt
	EXTI->RTSR |= EXTI_RTSR_TR0 + EXTI_RTSR_TR2 + EXTI_RTSR_TR3;
	EXTI->FTSR |= EXTI_FTSR_TR2 + EXTI_FTSR_TR3;
	
	// Initialise Encoder
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN; // Enable clock on GPIOC
	GPIOC->MODER |= 0x00000005;	// Set output mode
	GPIOC->OTYPER &= ~(0x00000003); // Set to push/pull
	GPIOC->PUPDR |= 0x000000005; // Set as pull up
	
	// Initialise Decoder
	GPIOC->MODER &= ~(0x000000F0); // Set pins to input mode
	
	while(1)
	{
	}
}
	
void decoder(char Channel, int newValue)
{
	prevCharA = curCharA;
	prevCharB = curCharB;
	
	if(Channel=='a')
	{
		curCharA=newValue;
	}
	else if(Channel=='b')
	{
		curCharB=newValue;
	}
	
	if((prevCharA==1 && prevCharB==1 && curCharA==0 && curCharB==1 )||( prevCharA==0 && prevCharB==1 && curCharA==0 && curCharB==0 )||( prevCharA==0 && prevCharB==0 && curCharA==1 && curCharB==0 )||( prevCharA==1 && prevCharB==0 && curCharA==1 && curCharB==1))
	{
		encoderCounter++;
		return;
	}
	encoderCounter--;
	return;
}

// Encoder handler
void encoderWrite(int direction)
{
	if(direction==1)
	{
			if(encoderOutput == 00)
			{GPIOC->BSRRH |= 0x0003;
				encoderOutput =10;
			}
			else if(encoderOutput == 10)
			{GPIOC->BSRRH |= 0x0002;
					GPIOC->BSRRL |= 0x0001;
					encoderOutput = 11;
			}
			else if(encoderOutput == 11)
			{GPIOC->BSRRL |= 0x0003;
					encoderOutput = 01;
			}
			else if(encoderOutput == 01)
			{GPIOC->BSRRH |= 0x0001;
				GPIOC->BSRRL |= 0x0002;
				encoderOutput = 00;
			}
	}
	if(direction==0)
	{
			if(encoderOutput == 00)
			{GPIOC->BSRRH |= 0x0003;
					encoderOutput=01;
			}
			else if(encoderOutput == 10)
			{GPIOC->BSRRH |= 0x0002;
					GPIOC->BSRRL |= 0x0001;
				encoderOutput = 00;
			}
			else if(encoderOutput == 11)
			{GPIOC->BSRRL |= 0x0003;
				encoderOutput = 10;
			}
			else if(encoderOutput == 01)
			{GPIOC->BSRRH |= 0x0001;
					GPIOC->BSRRL |= 0x0002;
				encoderOutput = 11;
			}	
	}
}

// Button funtions
void EXTI0_IRQHandler()
{
	if (EXTI->PR & EXTI_PR_PR0) // Check source
	{
		EXTI->PR |= EXTI_PR_PR0; // Clear flag
			
			currentOutput = nextOutput;
			
			switch(currentOutput){
				case potentiometer:
					// Turn on LED 4, turn off LED 3&5
					GPIOE->BSRRL |= 0x0100;
					GPIOE->BSRRH |= 0x0600;
					nextOutput = encoder;
					break;
				case encoder:
					// Turn on LED 3, turn off LED 4&5
					GPIOE->BSRRL |= 0x0200;
					GPIOE->BSRRH |= 0x0500;
					nextOutput = average;
					break;
				case average:
					// Turn on LED 5, turn off LED 3&4
					GPIOE->BSRRL |= 0x0400;
					GPIOE->BSRRH |= 0x0300;
					nextOutput = potentiometer;
				break;
			}
	}
}

// Decoder functions
void EXTI2_TSC_IRQHandler()
{
	if(EXTI->PR & EXTI_PR_PR2) // Check source
	{
		EXTI->PR |= EXTI_PR_PR2; // Clear flag
		
		int newVal = 0;
		if((GPIOC->IDR & 0x00000004)==0x00000004)
		{
			newVal =  1;
		}
		decoder('a', newVal); // Decode function
	}
}

void EXTI3_IRQHandler()
{
	if(EXTI->PR & EXTI_PR_PR3) // Check source
	{
		EXTI->PR |= EXTI_PR_PR3; // Clear flag
		
		int newVal = 0;
		if((GPIOC->IDR & 0x00000008)==0x00000008)
		{
			newVal =  1;
		}
		decoder('b', newVal); // Decode function
	}
}
	
// Timer 3 interrupt
void TIM3_IRQHandler()
{
if ((TIM3->SR & TIM_SR_UIF) !=0) // Check interrupt source is from the �Update� interrupt flag
{
	// Throttle position
	if(Ascending==1)//Ascending 
	{
		throttlePos += resolution;
		
		// Increment
		encoderWrite(1);
		
		if(throttlePos>=maxAmp)
		{
			throttlePos=maxAmp;
			Ascending=0;// Descending
		}
	}
	else if(Ascending==0) //Descending 
	{
		throttlePos -= resolution;
		
		// Decrement
		encoderWrite(0);
		
		if(throttlePos==0)
		{
			throttlePos=0;
			Ascending=1; // Ascending
		}
	}

	switch(currentOutput){
		case potentiometer:
			break;
		case encoder:
			GPIOE->BSRRL |= (encoderCounter>>4)<<11; //Turn counter LEDs on
			GPIOE->BSRRH |= (~encoderCounter>>4)<<11;	
			break;
		case average:
			break;
	}
}
TIM3->SR &= ~TIM_SR_UIF; // Reset �Update� interrupt flag in the SR register
}